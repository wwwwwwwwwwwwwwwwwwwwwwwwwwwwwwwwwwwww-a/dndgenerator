import os
import re
import sqlite3

import requests
import urllib3
from flask import Flask, render_template, request, redirect, url_for, session, g, flash
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from werkzeug.security import generate_password_hash, check_password_hash

# отключение предупреждений для самоподписанных сертификатов, если они используются во внешней среде
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

app = Flask(__name__)
# ключ должен быть вынесен в переменные окружения в продакшн-среде
app.secret_key = 'super_secret_dnd_key'
DATABASE = 'database.db'


# вспомогательная функция для преобразования hex-кода цвета в rgb-строку для использования в css
def hex_to_rgb_string(hex_color):
    try:
        hex_color = hex_color.lstrip('#')
        rgb = tuple(int(hex_color[i:i + 2], 16) for i in (0, 2, 4))
        return f"{rgb[0]}, {rgb[1]}, {rgb[2]}"
    except:
        return "106, 13, 173"


# управление соединением с базой данных в рамках контекста приложения
def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        # использование row_factory для доступа к колонкам по имени
        db.row_factory = sqlite3.Row
    return db


# закрытие соединения с бд при завершении контекста запроса
@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()


# инициализация схемы базы данных при первом запуске
def init_db():
    with app.app_context():
        db = get_db()
        with open('schema.sql', mode='r') as f:
            db.cursor().executescript(f.read())
        db.commit()


# внедрение пользовательских настроек во все шаблоны для динамической темизации
@app.context_processor
def inject_user_preferences():
    theme = 'dark'
    accent = '#6a0dad'
    font_key = 'tana'

    # получение настроек авторизованного пользователя
    if 'user_id' in session:
        try:
            db = get_db()
            user = db.execute('SELECT theme, accent_color, font FROM users WHERE id = ?',
                              (session['user_id'],)).fetchone()
            if user:
                theme = user['theme']
                accent = user['accent_color']
                font_key = user['font'] if user['font'] else 'tana'
        except Exception:
            pass

    # конвертация цвета для css переменных
    try:
        hex_c = accent.lstrip('#')
        r, g, b = tuple(int(hex_c[i:i + 2], 16) for i in (0, 2, 4))
        accent_rgb = f"{r}, {g}, {b}"
    except:
        accent_rgb = "106, 13, 173"
        r, g, b = 106, 13, 173

    # логика определения контрастности для автоматического добавления обводки текста
    # подсчет количества каналов, превышающих порог яркости
    high_vals = sum(1 for c in (r, g, b) if c > 240)
    low_vals = sum(1 for c in (r, g, b) if c < 50)

    outline_color = 'transparent'

    # применение черной обводки для светлой темы с очень светлым акцентом
    if theme == 'white' and high_vals >= 2:
        outline_color = '#000000'
    # применение белой обводки для темной темы с очень темным акцентом
    elif theme == 'dark' and low_vals >= 2:
        outline_color = '#ffffff'

    # маппинг ключей шрифтов к реальным css-семействам
    fonts_map = {
        'tana': "'Tana Uncial SP', serif",
        'times': "'Times New Roman', Times, serif",
        'arial': "Arial, Helvetica, sans-serif",
        'roboto': "'Roboto', sans-serif"
    }
    current_font_css = fonts_map.get(font_key, fonts_map['tana'])

    return dict(
        current_theme=theme,
        current_accent=accent,
        current_accent_rgb=accent_rgb,
        current_font=font_key,
        current_font_css=current_font_css,
        current_outline=outline_color
    )


@app.route('/')
def index():
    if 'user_id' not in session: return redirect(url_for('login'))
    return render_template('generator_page.html')


# обработчик генерации персонажа через внешний api
@app.route('/generate', methods=['POST'])
def generate():
    if 'user_id' not in session: return redirect(url_for('login'))

    # сбор данных из формы с установкой значений по умолчанию
    raw_level = request.form.get('level') or '1 уровень'
    raw_class = request.form.get('class') or 'Случайный класс'
    user_input_name = request.form.get('name')
    raw_name = user_input_name or 'Без имени'

    data = {
        'type': request.form.get('type') or 'Персонаж',
        'level': raw_level,
        'sex': request.form.get('sex') or 'Случайно',
        'race': request.form.get('race') or 'Случайно',
        'class': raw_class,
        'name': raw_name,
        'extra': request.form.get('extra') or ''
    }

    # формирование промпта для llm с жесткими инструкциями по структуре ответа
    prompt = (
        f"Ты опытный Мастер Подземелий (D&D 5e). Создай персонажа или НПС четко по заданным условиям."
        f"\nВводные данные (если 'Случайно' - придумай логично и органично чтобы все сочеталось(подбирай по расе("
        f"если раса не указана то опирайся на то в какую секунду десятисекундия тебе пришел запрос например("
        f"13:56:21 это первая секунда десятисекундия) тогда 1 - Ельф, 2 - Тифлинг, 3 - Полуэльф, 4 - Человек, 5 - Дварф,"
        f" 6 - Драконорожденый, 7 - Полурослик, 8 - Кобольд, 9 - Орк, 0 - Плазмоид))"
        f"\nесли в одном из входных полей указан бред или что-то непонятное то игнорируй либо пытайся найти что-то похожее связанное с днд):"
        f"\nХарактеристики создавай согласно уровню и особенностям рас и классов укажи значение и модификатор, например: 16 (+3)). Распредели очки логично для класса, расы и уровня."
        f"\n- Тип(персонаж игрока или нпс): {data['type']}"
        f"\n- Уровень: {data['level']}"
        f"\n- Пол: {data['sex']}"
        f"\n- Раса: {data['race']}"
        f"\n- Класс: {data['class']}"
        f"\n- Имя: {data['name']}"
        f"\n- Детали: {data['extra']}"
        f"\n\n"
        f"Твоя задача вывести результат в строго формате заданном структурой НИЧЕГО ЛИШНЕГО СТРОГО СООТВЕТСТВУЙ СТУКТУРЕ."
        f"\n Не пиши никаких размышлений или чего угодно другого, твой ответ пункты с 1 по 12"
        f"\nСтруктура:"
        f"\n1. Имя"
        f"\n2. Пол"
        f"\n3. Уровень"
        f"\n4. Раса(+ архетип)"
        f"\n5. Класс"
        f"\n6. Физические данные: рост, вес, возраст, размер, скорость"
        f"\n7. Мировоззрение"
        f"\n8. Характеристики (Stats): Сила, Ловкость, Телосложение, Интеллект, Мудрость, Харизма"
        f"\n9. Боевые параметры: Класс Доспеха (КД), Хиты (HP), Скорость."
        f"\n10. Спасброски: Сила Ловкость Телосложение Интеллект Мудрость Харизма (согласно расе и классу)"
        f"\n11. Навыки  Акробатика(Лов) Анализ(Инт) Атлетика(Сил) Внимательность(Мдр) Выживание(Мдр) Выступление(Хар)"
        f" Запугивание(Хар) История(Инт) Ловкость рук(Лов) Магия(Инт) (подбери согласно расе и классу)"
        f"\n12. Инвентарь: Оружие, броня и 1 интересный предмет(вплетенный в предысторию), деньги + другие возможные предметы."
        f"\n13. Внешность и Характер: Подробное атмосферное описание."
        f"\n14. Краткая предыстория.")

    try:
        # настройка стратегии повторных запросов для обеспечения стабильности соединения
        session_req = requests.Session()
        retry = Retry(
            total=3,
            backoff_factor=1,
            status_forcelist=[500, 502, 503, 504],
            allowed_methods=["POST"]
        )
        adapter = HTTPAdapter(max_retries=retry)
        session_req.mount('http://', adapter)
        session_req.mount('https://', adapter)

        headers = {
            "User-Agent": "Mozilla/5.0 ...",
            "Content-Type": "application/json"
        }

        # запрос к api генерации текста
        response = session_req.post(
            'https://text.pollinations.ai/',
            headers=headers,
            json={
                "messages": [
                    {"role": "system", "content": "Ты эксперт по D&D 5e..."},
                    {"role": "user", "content": prompt}
                ],
                "model": "mistral",
                "seed": 42
            },
            timeout=300,
            verify=False
        )

        if response.status_code != 200: raise Exception(f"Код {response.status_code}")
        result_text = response.text

        # валидация ответа на наличие html-тегов, свидетельствующих об ошибке
        if not result_text or "<html" in result_text: raise Exception("Ошибка сервера")

        # очистка текста от мета-тегов мышления модели
        result_text = re.sub(r'<thought>.*?</thought>', '', result_text, flags=re.DOTALL)

        # парсинг имени и класса из сгенерированного текста с помощью регулярных выражений
        final_name = data['name']
        if not user_input_name or user_input_name.strip() == "":
            name_match = re.search(r'1\.\s*(?:\*\*|)?Имя(?:\*\*|)?[:\s]*(.+)', result_text, re.IGNORECASE)
            if name_match:
                extracted_name = name_match.group(1).strip().strip('*')
                if extracted_name:
                    final_name = extracted_name

        final_class = data['class']
        class_match = re.search(r'4\.\s*(?:\*\*|)?Класс(?:\*\*|)?[:\s]*(.+)', result_text, re.IGNORECASE)

        if class_match:
            extracted_class = class_match.group(1).strip().strip('*')
            if extracted_class:
                final_class = extracted_class

        # сохранение результата в базу данных
        db = get_db()
        name_tag = f"{data['level']} • {final_class} • {final_name}"

        db.execute(
            'INSERT INTO characters (user_id, name_tag, content) VALUES (?, ?, ?)',
            (session['user_id'], name_tag, result_text)
        )
        db.commit()

        return render_template('generator_page.html', result=result_text)

    except Exception as e:
        flash(f"Ошибка генерации: {e}")
        return redirect(url_for('index'))


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if len(password) < 8:
            flash("Пароль мин. 8 символов.")
            return redirect(url_for('register'))
        db = get_db()
        try:
            hashed_pw = generate_password_hash(password)
            cursor = db.execute('INSERT INTO users (username, password) VALUES (?, ?)', (username, hashed_pw))
            db.commit()

            # авто-логин
            session['user_id'] = cursor.lastrowid
            session['username'] = username

            flash("Добро пожаловать!")
            return redirect(url_for('index'))
        except sqlite3.IntegrityError:
            flash("Имя занято.")
    return render_template('register_page.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        db = get_db()
        user = db.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
        if user and check_password_hash(user['password'], password):
            session['user_id'] = user['id']
            session['username'] = user['username']
            return redirect(url_for('index'))
        flash("Ошибка входа.")
    return render_template('login_page.html')


@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))


@app.route('/profile')
def profile():
    if 'user_id' not in session: return redirect(url_for('login'))
    db = get_db()
    chars = db.execute('SELECT * FROM characters WHERE user_id = ? ORDER BY created_at DESC',
                       (session['user_id'],)).fetchall()
    return render_template('profile_page.html', chars=chars)


@app.route('/delete_char/<int:char_id>')
def delete_char(char_id):
    if 'user_id' not in session: return redirect(url_for('login'))
    db = get_db()
    db.execute('DELETE FROM characters WHERE id = ? AND user_id = ?', (char_id, session['user_id']))
    db.commit()
    return redirect(url_for('profile'))


@app.route('/settings', methods=['GET', 'POST'])
def settings():
    if 'user_id' not in session: return redirect(url_for('login'))
    if request.method == 'POST':
        theme = request.form.get('theme')
        accent = request.form.get('accent')
        font = request.form.get('font')

        db = get_db()
        db.execute(
            'UPDATE users SET theme = ?, accent_color = ?, font = ? WHERE id = ?',
            (theme, accent, font, session['user_id'])
        )
        db.commit()
        flash("Настройки сохранены.")
        return redirect(url_for('settings'))
    return render_template('settings_page.html')


if __name__ == '__main__':
    if not os.path.exists(DATABASE):
        init_db()
    app.run(debug=True) # можно добавить именованый аргумент port если порт 5000 уже используется